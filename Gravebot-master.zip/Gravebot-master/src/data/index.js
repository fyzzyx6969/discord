export choices from './choices';
export drama from './drama';
export eightball from './eightball';
export emoji from './emoji';
export const lol_champs = require('./lol_champs.json');
export const lol_items = require('./lol_items.json');
export memes from './memes';
export quotes from './quotes';
