export default [
  'ar', // Arabic
  'bs', // Bosnian
  'bg', // Bulgarian
  'ca', // Catalan
  'cs', // Czech
  'da', // Danish
  'de', // German
  'el', // Greek
  'en', // English
  'es', // Spanish
  'fi', // Finish
  'fr', // French
  'he', // Hebrew
  'hr', // Croatian
  'hu', // Hungarian
  'id', // Indonesian
  'it', // Italian
  'ja', // Japanese
  'ka', // Georgian
  'ko', // Korean
  'ms', // Malay
  'no', // Norwegian
  'lt', // Lithuanian
  'lv', // Latvian
  'nl', // Dutch
  'pl', // Polish
  'pt', // Portuguese
  'pt-br', // Brazillian Portuguese
  'ro', // Romanian
  'ru', // Russian
  'sk', // Slovak
  'sl', // Slovenian
  'sr', // Serbian
  'sv', // Swedish
  'th', // Thai
  'tr', // Turkish
  'vi', // Vietnamese
  'zh-cn', // Chinese Simplified
  'zh-tw' // Chinese Traditional
];
